<footer class="app-footer">
    <div class="container text-center py-3">
        <!--/* This template is free as long as you keep the footer attribution link. If you'd like to use the template without the attribution link, you can buy the commercial license via our website: themes.3rdwavemedia.com Thank you for your support. :) */-->
       

    </div>
</footer>
<!--//app-footer-->

</div>
<!--//app-wrapper-->


<!-- Javascript -->
<script src="../popper.min.js"></script>
<script src="../bootstrap.min.js"></script>


<!-- Page Specific JS -->
<script src="../app.js"></script>
<script type="text/javascript" src="../jquery.min.js"></script>
</body>

</html>